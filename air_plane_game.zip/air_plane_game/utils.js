const air_planes_raw_img = [
                    
                    "ship_0000.png"
                    ,"ship_0001.png"
                    ,"ship_0002.png"
                    ,"ship_0003.png"
                    ,"ship_0004.png"
                    ,"ship_0005.png"
                    ,"ship_0006.png"
                    ,"ship_0007.png"
                    ,"ship_0008.png"
                    ,"ship_0009.png"
                    ,"ship_0010.png"
                    ,"ship_0011.png"
                    ,"ship_0012.png"
                    ,"ship_0013.png"
                    ,"ship_0014.png"
                    ,"ship_0015.png"
                    ,"ship_0016.png"
                    ,"ship_0017.png"
                    ,"ship_0018.png"
                    ,"ship_0019.png"               
]
const bullet_raw_img = [
    "tile_0000.png"
    ,"tile_0001.png"
    ,"tile_0015.png"
    ,"tile_0003.png"

]
const collectables_raw_img = [
    "tile_0024.png"
    ,"tile_0025.png"
    ,"tile_0016.png"

    
]
const collectables_out_come = ["health","bullet","vector"]


let planet_raw_img = [
    "saturn.png","earth.png","real mars.png","mars.png","wonder planet.png"
]
let planets_vector = [
    [1.0, -1.2], [-1.4, 0.8], [0.9, -1.1], [-1.3, 1.1], [1.4, -0.9],
    [0.5, -1.4], [-1.1, 0.7], [1.3, -0.8], [-0.6, 1.2], [1.2, -0.7],
    [-0.8, 1.4], [0.6, -1.0], [-1.2, 0.9], [1.1, -1.0], [-0.9, 1.3],
    [1.0, -0.8], [-1.5, 0.5], [0.7, -1.3], [-1.3, 0.6], [1.2, -0.9]
  ]
const air_plane_img = []
const bullet_img = []
const collectables_img = []
const planet_img = []
const enemy_strength_as_level_increase = [
    // r, speed, life, bullet_speed, bullet_dlay, bullet_level, bullet_vector_level,
    [20,1,10,1.5,2000,0,0],
    [20,1,8,1,1000,1,1],
    [50,0.3,8,0.3,600,0,2],
    [15,1,3,1,70,0,0],
    [26,2.8,10,1,700,3,2]

]
function make_img(){
   for(let s of air_planes_raw_img){
    const  img = new Image();
    img.src = s
    air_plane_img.push(img)
    }
    for(let s of bullet_raw_img){
        const  img = new Image();
        img.src = s
        bullet_img.push(img)
    }
    for(let s of collectables_raw_img){
        const  img = new Image();
        img.src = s
        collectables_img.push(img)
    }
    for(let s of planet_raw_img){
        const  img = new Image();
        img.src = s
        planet_img.push(img)
    }
}
make_img()
function rand_air_plane(indx){
    if(indx){
        return air_plane_img[indx]
    }else{
        return air_plane_img[rand(4)]
    }
}
function rand_bullet(indx){
    if(indx){
        return bullet_img[indx]
    }else{
        return bullet_img[rand(4)]
    }
}

function play_sound(s){
    const a = document.createElement("audio")
    a.src = s
    a.play
}



function rand(range){
    return Math.floor(Math.random()*range)
}