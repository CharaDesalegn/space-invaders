class Display{
    constructor(x,y,persent,img,color,ctx){
        this.x = x
        this.y = y
        this.persent = persent
        this.color = color
        this.ctx = ctx
        this.img = img
        this.x_offset = 27
        this.y_offset = 10
        this.update()
    }
    update(){
        this.draw(this.ctx)
    }
    draw(ctx){
        ctx.drawImage(this.img,this.x,this.y,25,25);  
       
        ctx.beginPath()
        ctx.rect(this.x+this.x_offset,this.y+this.y_offset,100,5)
        ctx.fillStyle = this.color
        ctx.strokeStyle = this.color

        ctx.fillRect(this.x+this.x_offset,this.y+this.y_offset,this.persent,5)
        ctx.stroke()
    }
}


class Planet{
    constructor(x,y,r,speed,img,ctx,vector){
        this.x = x
        this.y = y
        this.r = r
        this.img = img
        this.speed = speed
        this.ctx = ctx
        this.vector = vector
    }
    update(){
        this.draw(this.ctx)
        
    }
    draw(ctx){
        this.x+= this.vector[0] * this.speed
        this.y+= this.vector[1] * this.speed
        ctx.drawImage(this.img,this.x,this.y,this.r,this.r);  

    }
}

