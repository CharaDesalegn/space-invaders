


class AirPlane{
    constructor(x,y,r,ctx,type,speed,bullet_speed,bullet_delay){
        this.x = x
        this.y = y
        this.r = r
        this.life = 100
        this.ctx = ctx
        this.w = r
        this.type = type
        this.speed = speed
        this.bullet_speed = bullet_speed
        this.img = rand_air_plane()
        this.bullet_delay = bullet_delay
        this.bullet_level = 0
        this.bullet_vector_level = 0
        this.bullet_level_second = 0
        this.bullet_vector_level_second = 0
        this.collectables = "404"
        
        
        setInterval(()=>{
            if(this.life > 0){
                let vectors = bullet_vectors[this.bullet_vector_level].slice()
                for(let v of vectors){
                    let vct = v.slice()
                    if(this.type == "enemy"){
                        vct[1]*= -1
                    }
                    let b = new Bullet(this.x,this.y,10,this.ctx,vct,this.type,this.bullet_level,this.bullet_speed)
                    bullets.push(b)
                }
                
                
            }
        }, this.bullet_delay)
        this.update()
        
    }
    update(){
        if(this.type == "enemy" || this.type == "dommy"){
            this.y += this.speed
        }
        if(this.collectables != "none"){
            this.draw(this.ctx)
        }
        
    }
    draw(ctx){
        
        // ctx.beginPath()
        // ctx.arc(this.x,this.y,this.r,0,Math.PI*2)
        // ctx.stroke()

        ctx.drawImage(this.img,this.x-this.r,this.y-this.r, this.w*2,this.w*2);  
    }
}

