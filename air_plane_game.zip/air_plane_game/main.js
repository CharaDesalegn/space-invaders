const canvas = document.getElementById("canvas")
const canvas_2 = document.getElementById("canvas2")

const bomb_sound = document.getElementById("bomb")
const collectables_sound = document.getElementById("collectables")
const background_music = document.getElementById("background_musci")
const gun_fire_sound = document.getElementById("gun_fire")

bomb_sound.volume = 0.2
gun_fire_sound.volume = 0.2

document.addEventListener('keydown', function() {
    background_music.play();
    // gun_fire_sound.play()
}, { once: true })
const board = document.getElementById("board")
const health = document.getElementById("health")
let score = 0
let level = enemy_strength_as_level_increase.length
const width = 350
const height = 600
const width2 = window.innerWidth
const height2 = innerHeight
canvas_2.width = width2
canvas_2.height = height2

canvas.width = width
canvas.height = height
// canvas.style.backgroundColor = "gray"
// canvas_2.style.backgroundColor = "gray"

const context = canvas.getContext("2d")
const context_2 = canvas_2.getContext("2d")
const health_display = new Display(0,3,100,collectables_img[0],"red",context)
const bullet_display = new Display(0,30,100,collectables_img[1],"lightblue",context)
const bullet_vector_display = new Display(0,59,10,collectables_img[2],"red",context)
let enemys = []
let collectables = []
let displays = [health_display,bullet_display,bullet_vector_display]
let planets = []
// for(let i = 0;i<width2;i++){
//     const p = new Planet(rand(width2),rand(height2),rand(2),0,planetColors[rand(planetColors.length)],canvas_2,planets_vector[rand(planets_vector.length)])
//     planets.push(p)
// }

const player = new AirPlane(width/2,height-50,25,context,"player",10,1,100)
setInterval(()=>{
    let x = rand(width2*2)-width2
    let y = rand(height2*2)-height2
    console.log(planets.length)
    // if(x > width2 || x < 0){
    //     if(y > height2 || y < 0){
            const p = new Planet(x,y,rand(100),rand(4)+1,planet_img[rand(planet_img.length)],canvas_2,planets_vector[rand(planets_vector.length)])
            planets.push(p)

    let info = enemy_strength_as_level_increase[rand(level)]
    const enemy = new AirPlane(rand(width-30)+15,50,info[0],context,"enemy",1,0.5,info[4])
    enemy.speed = info[1]
    enemy.life = info[2]
    enemy.bullet_speed = info[3]
    enemy.bullet_level = info[5]
    enemy.bullet_vector_level = info[6]

    enemys.push(enemy)
},2000)

setInterval(()=>{

    if(player.bullet_level_second > 0){
        player.bullet_level_second-= player.bullet_level
    }else if (player.bullet_level_second <= 0){
        player.bullet_level = 0
    }
    if(player.bullet_vector_level_second > 0){
        player.bullet_vector_level_second-=player.bullet_vector_level*2
    }else if (player.bullet_vector_level_second <= 0){
        player.bullet_vector_level = 0
    }
},500)

health.innerText = "health: " + player.life

function enemy_update(){
    for(let e of enemys){
        e.update()
        if(Math.sqrt(Math.pow(e.y-player.y,2)+Math.pow(e.x-player.x,2)) < player.r-10+e.r){
        
        }

        if(e.life <= 0 || e.y >= height){
            if(e.life <= 0){
                score += 1
                board.innerText = score
                bomb_sound.play()
            }
            for(let m = 0;m<enemys.length;m++){if(enemys[m]==e){
                if(enemys[m].life <= 0){
                    enemys[m].speed = 0.5
                    enemys[m].r = 10
                    enemys[m].w = 10
                    enemys[m].type = "dommy"
                    let i = rand(collectables_img.length)
                    enemys[m].img = collectables_img[i]
                    let r = rand(4)
                    if(r == 0){
                        enemys[m].collectables = collectables_out_come[i]
                    }
                    else{
                        enemys[m].collectables = "none"
                    }
                    collectables.push(enemys[m])
                }

                enemys[m].life = 0
                enemys.splice(m,1)}}

        }
    }
}
function collectables_update(){
    for(let c of collectables){
        c.update()
        if(c.y > height || c.collectables == "none"){
            for(let m = 0;m<collectables.length;m++){if(collectables[m]==c){
                collectables.splice(m,1)}}
        }else if(Math.sqrt(Math.pow(c.y-player.y,2)+Math.pow(c.x-player.x,2)) < player.r-10+c.r){
                for(let m = 0;m<collectables.length;m++){if(collectables[m]==c){
                    collectables_taken(collectables[m].collectables)
                    collectables_sound.play()
                    collectables.splice(m,1)
                }}
            }
        }
}
function displays_update(){
    for(let d of displays){
        d.draw(context)
    }
    health_display.persent = player.life
    bullet_display.persent = player.bullet_level_second
    bullet_vector_display.persent = player.bullet_vector_level_second
}
function planets_update(){
    for(let p of planets){
        p.draw(context_2)
        if(p.x > width2*2 || p.x < -width2 || p.y > height2*2 || p.y < -height2){
            for(let m = 0;m<planets.length;m++){if(planets[m]==p){planets.splice(m,1)}}
        }
    }
}
function collectables_taken(power){
    if(power == "bullet"){
        player.bullet_level_second = 100
        if(player.bullet_level < bullet_img.length-1){
            player.bullet_level++
        }
    }else if(power == "health" && player.life < 80){
        player.life+= 20
        health.innerText = "health: " + player.life
    }else if(power == "vector"){
        player.bullet_vector_level_second = 100
        if(player.bullet_vector_level < bullet_vectors.length-2){
            player.bullet_vector_level++
        }
    }
}

// player.bullet_vector_level = 2
// player.bullet_level = 1


function move_player(e) {
        if(e.key == 'ArrowUp' && player.y-player.r > 0){
            player.y -= player.speed;  // Move up
        }else if(e.key == 'ArrowDown' && player.y+player.r < height){
            player.y += player.speed;  // Move up
        }if(e.key == 'ArrowRight' && player.x+player.r < width){
            player.x += player.speed;  // Move up
        }else if(e.key == 'ArrowLeft' && player.x-player.r > 0){
            player.x -= player.speed;  // Move up
        }
    
}
window.addEventListener('keydown', move_player);

function update(){
    context.clearRect(0,0,width,height) 
    context_2.clearRect(0,0,width2,height2) 


    player.update()
    enemy_update()
    bullet_update()
    displays_update()
    collectables_update()
    planets_update()




    requestAnimationFrame(update)
}
update()
// setInterval(update,100)