let bullets = []
const  bullet_vectors = [[[0,-5]],[[0,-5],[1,-4],[-1,-4]],[[0,-5],[1,-4],[-1,-4],[2,-4],[-2,-4]],[0,0]]
class Bullet{
    constructor(x,y,r,ctx,dr,parent,level,speed){
        this.x = x
        this.y = y
        this.r = r
        this.ctx = ctx
        this.w = r
        this.speed = speed
        this.dr = dr
        this.parent = parent
        this.img = bullet_img[level]
        this.dameg = level + 1
        this.update()
        // if(parent == "enemy" && this.dr[1] < 0){
        //     this.dr[1]*= -1
        // }else if(parent == "player" && this.dr[1] > 0){
        //     this.dr[1]*= -1
        // }
        // console.log(dr)
        
    }
    update(){
        this.draw(this.ctx)
        this.y+=+this.dr[1] * this.speed
        this.x+=+this.dr[0] * this.speed
    }
    draw(ctx){
        
        ctx.drawImage(this.img,this.x-this.r,this.y-this.r, this.w*2,this.w*2);  
    }
}
function bullet_update(){
    for(let bullet of bullets){
        bullet.update()
        if(bullet.x > width || bullet.x < 0 || bullet.y > height || bullet.y < 0){
            for(let m = 0;m<bullets.length;m++){if(bullets[m]==bullet){bullets.splice(m,1)}}
        }else if(bullet.parent == "player"){
            for(let e of enemys){
                if(Math.sqrt(Math.pow(bullet.y-e.y,2)+Math.pow(bullet.x-e.x,2)) < e.r+bullet.r){
                    for(let m = 0;m<bullets.length;m++){if(bullets[m]==bullet){bullets.splice(m,1)}}
                    e.life-= bullet.dameg
                }
            }
        }else{
            if(Math.sqrt(Math.pow(bullet.y-player.y,2)+Math.pow(bullet.x-player.x,2)) < player.r-10+bullet.r){
                for(let m = 0;m<bullets.length;m++){if(bullets[m]==bullet){bullets.splice(m,1)}}
                player.life-= bullet.dameg
                health.innerText = "health: " + player.life

            }

        }

    }
}
// bullet_update()
// setInterval(bullet_update,100)